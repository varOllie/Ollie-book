# MessageTyping
Show a status of friend in chat if he is tying a message or not.
